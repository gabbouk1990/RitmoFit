/* Parses iCalendar exported from a Supershift/iOS calendar, without uploading it. */
function icsDate(raw) {
 const s=String(raw||'').replace(/[^\dTZ]/g,'');
 if(!s)return null;
 if(s.length===8)return s.slice(0,4)+'-'+s.slice(4,6)+'-'+s.slice(6,8);
 const iso=`${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}T${s.slice(9,11)}:${s.slice(11,13)}:${s.slice(13,15)||'00'}${s.endsWith('Z')?'Z':''}`;
 const d=new Date(iso);return Number.isFinite(d.getTime())?d.toISOString():null;
}
export function classifyShift(summary) {
 const s=String(summary||'').toLowerCase().trim();
 if(/\b(smonto|post.?notte|night.?off)\b/.test(s)||s==='sm')return 'Smonto';
 if(/\b(riposo|libero|rest|off|ripo)\b/.test(s)||s==='r')return 'Riposo';
 if(/\b(ferie|congedo|vacation)\b/.test(s))return 'Ferie';
 if(/\b(notte|night|turno n|^n$)\b/.test(s))return 'Notte';
 if(/\b(pomeriggio|afternoon|turno p|^p$)\b/.test(s))return 'Pomeriggio';
 if(/\b(mattina|morning|turno m|^m$)\b/.test(s))return 'Mattina';
 return 'Altro';
}
export function parseICS(source) {
 const lines=source.replace(/\r\n/g,'\n').replace(/\r/g,'\n').split('\n'); const flat=[];
 for(const line of lines){if((line[0]===' '||line[0]==='\t')&&flat.length)flat[flat.length-1]+=line.slice(1);else flat.push(line);}
 let cur=null;const events=[];
 for(const line of flat){
  if(line==='BEGIN:VEVENT'){cur={};continue;}
  if(line==='END:VEVENT'){
   if(cur?.start){const summary=cur.summary||'Turno'; const date=cur.start.slice(0,10);events.push({id:cur.uid||[date,summary,cur.start].join('|'),date,start:cur.start,end:cur.end||'',displayStart:cur.displayStart||'',displayEnd:cur.displayEnd||'',label:summary,type:classifyShift(summary),source:'ics'});}
   cur=null;continue;
  }
  if(!cur)continue;const colon=line.indexOf(':');if(colon<0)continue;
  const keyRaw=line.slice(0,colon);const key=keyRaw.split(';')[0].toUpperCase();const val=line.slice(colon+1).replace(/\\n/gi,' ').replace(/\\,/g,',').replace(/\\;/g,';');
  if(key==='SUMMARY')cur.summary=val;
  if(key==='DTSTART')cur.start=icsDate(val);
  if(key==='DTEND')cur.end=icsDate(val);
  if(key==='DTSTART'||key==='DTEND'){
    const localTime=val.match(/^\d{8}T(\d{2})(\d{2})/);
    if(localTime&&!val.endsWith('Z'))cur[key==='DTSTART'?'displayStart':'displayEnd']=localTime[1]+':'+localTime[2];
  }
  if(key==='UID')cur.uid=val;
 }
 return events.sort((a,b)=>a.date.localeCompare(b.date));
}
