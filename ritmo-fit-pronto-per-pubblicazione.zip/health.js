/* Apple Health XML and ZIP import. All processing happens on the user's device. */
const DECODER = new TextDecoder('utf-8');
const prefixes = ['HKQuantityTypeIdentifier', 'HKCategoryTypeIdentifier', 'HKWorkoutActivityType'];
const SUM_HINT = /(StepCount|ActiveEnergyBurned|BasalEnergyBurned|Distance|AppleExerciseTime|AppleStandTime|FlightsClimbed|SwimmingStrokeCount|PushCount|DietaryEnergyConsumed|DietaryProtein|DietaryCarbohydrates|DietaryFatTotal|DietaryWater)/;
const UNIT_MAP = { 'Cal':'kcal', 'kcal':'kcal', 'kJ':'kJ', 'count':'', 'min':'min', 'sec':'s', 'km':'km', 'm':'m', 'mi':'mi', 'kg':'kg', 'g':'g', 'lb':'lb', 'bpm':'bpm', 'ms':'ms', '%':'%', 'mL':'mL' };
function friendly(s) { return String(s||'').replace('HKQuantityTypeIdentifier','').replace('HKCategoryTypeIdentifier','').replace('HKWorkoutActivityType','').replace(/([a-z])([A-Z])/g,'$1 $2').trim(); }
function attrs(tag) {
  const a={}; const re=/([A-Za-z_][\w:.-]*)="([^"]*)"/g; let m;
  while((m=re.exec(tag))!==null) a[m[1]]=m[2].replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
  return a;
}
function dayOf(str) { const s=String(str||''); const m=s.match(/^(\d{4}-\d{2}-\d{2})/); return m ? m[1] : ''; }
function dateVal(str) { const d = new Date(String(str||'').replace(' ','T').replace(' +','+').replace(' -','-')); return Number.isFinite(d.getTime()) ? d.getTime() : null; }
function toNum(val) { const n=Number(val); return Number.isFinite(n)?n:null; }
function addMetric(dayObj, type, value, unit, mode) {
  const n=toNum(value); if(n===null) return;
  const m=dayObj.metrics[type] ||= {sum:0, count:0, min:n, max:n, unit:unit||'', mode:mode||'avg'};
  // Preserve all underlying numeric metric categories rather than throwing unknown Health types away.
  m.sum+=n; m.count++; m.min=Math.min(m.min,n); m.max=Math.max(m.max,n);
}
function parseZipDirectory(ab) {
  const view=new DataView(ab); let eocd=-1;
  for(let i=ab.byteLength-22;i>=0;i--) { if(view.getUint32(i,true)===0x06054b50) { eocd=i; break; } }
  if(eocd<0) throw new Error('Archivio ZIP non riconosciuto.');
  const cdSize=view.getUint32(eocd+12,true), cdOffset=view.getUint32(eocd+16,true);
  if(cdSize===0xffffffff||cdOffset===0xffffffff) throw new Error('ZIP64 non supportato: estrai export.xml sul dispositivo.');
  return {cdSize,cdOffset};
}
async function locateHealthXML(file) {
  if(/\.xml$/i.test(file.name)) return {stream:file.stream(), size:file.size};
  if(!/\.zip$/i.test(file.name)) throw new Error('Seleziona un file export.xml oppure esportazione.zip di Apple Salute.');
  const tailStart=Math.max(0,file.size-65557); const tail=await file.slice(tailStart).arrayBuffer();
  const {cdSize,cdOffset}=parseZipDirectory(tail);
  // The central-directory offsets refer to the beginning of the ZIP, not the sliced tail.
  const dv=new DataView(tail); let eocd=-1; for(let i=tail.byteLength-22;i>=0;i--){if(dv.getUint32(i,true)===0x06054b50){eocd=i;break;}}
  let off=cdOffset, size=cdSize;
  const central=await file.slice(off,off+size).arrayBuffer(); const cv=new DataView(central); let p=0, found=null;
  while(p+46<=central.byteLength) {
    if(cv.getUint32(p,true)!==0x02014b50) break;
    const comp=cv.getUint16(p+10,true), compressed=cv.getUint32(p+20,true), raw=cv.getUint32(p+24,true);
    const nameLen=cv.getUint16(p+28,true), extra=cv.getUint16(p+30,true), comment=cv.getUint16(p+32,true), localOffset=cv.getUint32(p+42,true);
    const name=DECODER.decode(new Uint8Array(central,p+46,nameLen));
    if(name==='export.xml'||name.endsWith('/export.xml')) { found={name,comp,compressed,raw,localOffset}; break; }
    p+=46+nameLen+extra+comment;
  }
  if(!found) throw new Error('Nello ZIP non è presente export.xml.');
  const localBuf=await file.slice(found.localOffset,found.localOffset+30).arrayBuffer(); const lv=new DataView(localBuf);
  if(lv.getUint32(0,true)!==0x04034b50) throw new Error('Intestazione ZIP non valida.');
  const dataAt=found.localOffset+30+lv.getUint16(26,true)+lv.getUint16(28,true);
  const compressedFile=file.slice(dataAt,dataAt+found.compressed);
  if(found.comp===0) return {stream:compressedFile.stream(),size:found.raw};
  if(found.comp===8) {
    try { return {stream:compressedFile.stream().pipeThrough(new DecompressionStream('deflate-raw')),size:found.raw}; }
    catch { throw new Error('Il browser non può decomprimere questo ZIP. Aprilo in File ed importa export.xml.'); }
  }
  throw new Error('Compressione ZIP non supportata. Estrai export.xml e importalo direttamente.');
}
export async function parseHealthExport(file, onProgress=()=>{}) {
  const {stream,size}=await locateHealthXML(file);
  const reader=stream.getReader(); const decoder=new TextDecoder();
  let carry='', bytes=0, tags=0, current=null; const days={}; const workouts=[], recentHR={};
  const recentStart=new Date(); recentStart.setFullYear(recentStart.getFullYear()-3);
  const recentMin=recentStart.toISOString().slice(0,10);
  const dayObj=d=>days[d] ||= {metrics:{}, activity:null, categories:{}};
  function process(tag) {
    if(tag.startsWith('<?')||tag.startsWith('<!'))return;
    const closing=tag.startsWith('</'); const m=tag.match(/^<\/?([\w:]+)/); if(!m)return;
    const name=m[1], a=closing?{}:attrs(tag), selfClose=/\/\s*>$/.test(tag);
    if(name==='Workout') {
      if(closing) { if(current){workouts.push(current);current=null;} return; }
      const start=dayOf(a.startDate); if(!start)return;
      current={id:[a.workoutActivityType,a.startDate,a.endDate,a.sourceName].join('|'),type:friendly(a.workoutActivityType),rawType:a.workoutActivityType||'',start:a.startDate||'',end:a.endDate||'',date:start,
        duration:Number(a.duration)||0,durationUnit:a.durationUnit||'min',calories:toNum(a.totalEnergyBurned),energyUnit:a.totalEnergyBurnedUnit||'kcal',distance:toNum(a.totalDistance),distanceUnit:a.totalDistanceUnit||'km',source:a.sourceName||'',stats:{},events:[],metadata:{}};
      if(current.durationUnit==='sec')current.duration/=60;
      if(current.durationUnit==='h')current.duration*=60;
      if(selfClose){workouts.push(current);current=null;}
      return;
    }
    if(current && !closing && name==='WorkoutStatistics') {
      const key=friendly(a.type); current.stats[key]={unit:a.unit||'',sum:toNum(a.sum),avg:toNum(a.average),min:toNum(a.minimum),max:toNum(a.maximum)};
      if(current.calories==null&&/ActiveEnergyBurned/.test(a.type||'')) { current.calories=toNum(a.sum); current.energyUnit=a.unit||'kcal'; }
      if(current.distance==null&&/Distance(Swimming|WalkingRunning|Cycling)/.test(a.type||'')) {current.distance=toNum(a.sum);current.distanceUnit=a.unit||'m';}
      return;
    }
    if(current && !closing && name==='WorkoutEvent') { if(current.events.length<200)current.events.push({type:a.type||'',date:a.date||'',duration:a.duration||''});return; }
    if(current && !closing && name==='MetadataEntry'){ if(Object.keys(current.metadata).length<40)current.metadata[a.key||'meta']=a.value||'';return; }
    if(closing)return;
    if(name==='ActivitySummary'){
      const day=(a.dateComponents||'').slice(0,10); if(day)dayObj(day).activity={move:toNum(a.activeEnergyBurned),moveUnit:a.activeEnergyBurnedUnit,exercise:toNum(a.appleExerciseTime),stand:toNum(a.appleStandHours),moveGoal:toNum(a.activeEnergyBurnedGoal),exerciseGoal:toNum(a.appleExerciseTimeGoal)};
      return;
    }
    if(name==='Record'){
      const d=dayOf(a.startDate), type=friendly(a.type); if(!d||!type)return;
      const rec=dayObj(d);
      if(a.type.startsWith('HKQuantityTypeIdentifier')) {
        addMetric(rec,type,a.value,a.unit, SUM_HINT.test(type)?'sum':'avg');
        if(type==='Heart Rate'&&d>=recentMin){
          const t=dateVal(a.startDate), v=toNum(a.value);if(t!=null&&v!=null)(recentHR[d]||=[]).push([t,v]);
        }
      } else if(a.type.startsWith('HKCategoryTypeIdentifier')) {
        const cat=rec.categories[type] ||= {}; const k=String(a.value); cat[k]=(cat[k]||0)+1;
      }
    }
  }
  function scan(isFinal=false){
    let i=0;
    while(true){
      const begin=carry.indexOf('<',i); if(begin<0){carry='';break;}
      const end=carry.indexOf('>',begin+1); if(end<0){carry=carry.slice(begin);break;}
      process(carry.slice(begin,end+1));tags++;i=end+1;
      if(i>120000){carry=carry.slice(i);i=0;}
    }
  }
  try {
    while(true){const {value,done}=await reader.read();if(done)break;bytes+=value.byteLength;carry+=decoder.decode(value,{stream:true});scan();if(tags%5000===0 || bytes%10000000<value.byteLength)onProgress(Math.min(99,Math.round(bytes/Math.max(1,size)*100)),`Elaborati ${tags.toLocaleString('it-IT')} elementi`);}
    carry+=decoder.decode();scan(true);
  } finally {reader.releaseLock();}
  // Derive each workout's HR summary from individual samples in the same day (last 3 years).
  for(const d in recentHR)recentHR[d].sort((a,b)=>a[0]-b[0]);
  for(const w of workouts){
    const hr=[]; const start=dateVal(w.start),end=dateVal(w.end);
    if(start!=null&&end!=null) for(const day of new Set([w.date, new Date(end).toISOString().slice(0,10)])) {
      for(const [t,v] of (recentHR[day]||[]))if(t>=start&&t<=end)hr.push(v);
    }
    if(hr.length){w.heartRate={avg:Math.round(hr.reduce((a,b)=>a+b,0)/hr.length),min:Math.min(...hr),max:Math.max(...hr),samples:hr.length};}
    else {const h=w.stats['Heart Rate'];if(h)w.heartRate={avg:h.avg,min:h.min,max:h.max,samples:0};}
  }
  workouts.sort((a,b)=>String(b.start).localeCompare(String(a.start)));
  onProgress(100,`Completato: ${workouts.length} allenamenti e ${Object.keys(days).length} giorni`);
  return {importedAt:new Date().toISOString(),name:file.name,workouts,days,stats:{tags,workoutCount:workouts.length,dayCount:Object.keys(days).length,metricTypes:[...new Set(Object.values(days).flatMap(d=>Object.keys(d.metrics)))].sort()}};
}
export function dailyValue(day,type) {
  if(!day)return null;
  if(type==='Active Energy Burned'&&day.activity?.move!=null)return day.activity.move;
  if(type==='Apple Exercise Time'&&day.activity?.exercise!=null)return day.activity.exercise;
  const v=day.metrics?.[type];if(!v||!v.count)return null;return v.mode==='sum'?v.sum:v.sum/v.count;
}
export function metricUnit(day,type){return day?.metrics?.[type]?.unit||({'Active Energy Burned':'kcal','Apple Exercise Time':'min','Step Count':''})[type]||'';}
export {friendly};
